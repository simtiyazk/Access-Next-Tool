'use strict';

$(document).ready(function () {
  $(".gammagardISI").on('touchend', function (event) {
    event.stopPropagation();
    event.preventDefault();
    window.open('https://www.shirecontent.com/pi/pdfs/gamliquid_usa_eng.pdf');
  });
});
//# sourceMappingURL=access_next_tool_60_00.js.map
