// export default () => {
// 	$(document).ready(function() {

// 		//  control center swipe disable
// 		$('.cuvitru_content_slider').swipe({
// 			'swipe': function(event, direction, distance) {
// 			if (direction === 'left') {
// 				event.stopImmediatePropagation();
// 				$('.cuvitru-carousel').not(this).trigger('next.owl.carousel');
// 			} else if (direction === 'right') {
// 				event.stopImmediatePropagation();
// 				$('.cuvitru-carousel').not(this).trigger('prev.owl.carousel');
// 			}
// 			},
// 			threshold: 10
// 		});

// 		// Cuvitru slider swipe disable
// 		$('.output_content_slider').swipe({
// 			'swipe': function(event, direction, distance) {
// 			if (direction === 'left') {
// 				event.stopImmediatePropagation();
// 				$('.output-carousel').not(this).trigger('next.owl.carousel');
// 			} else if (direction === 'right') {
// 				event.stopImmediatePropagation();
// 				$('.output-carousel').not(this).trigger('prev.owl.carousel');
// 			}
// 			},
// 			threshold: 10
// 		});

// 		// hyqvia slider swipe disable
// 		$('.hyqvia_content_slider').swipe({
// 			'swipe': function(event, direction, distance) {
// 			if (direction === 'left') {
// 				event.stopImmediatePropagation();
// 				$('.hyqvia-carousel').not(this).trigger('next.owl.carousel');
// 			} else if (direction === 'right') {
// 				event.stopImmediatePropagation();
// 				$('.hyqvia-carousel').not(this).trigger('prev.owl.carousel');
// 			}
// 			},
// 			threshold: 10
// 		});

// 		// gammagard slider swipe disable
// 		$('.gammagard_content_slider').swipe({
// 			'swipe': function(event, direction, distance) {
// 			if (direction === 'left') {
// 				event.stopImmediatePropagation();
// 				$('.gammagard-carousel').not(this).trigger('next.owl.carousel');
// 			} else if (direction === 'right') {
// 				event.stopImmediatePropagation();
// 				$('.gammagard-carousel').not(this).trigger('prev.owl.carousel');
// 			}
// 			},
// 			threshold: 10
// 		});

// 		// takeda slider swipe disable
// 		$('.takeda_content_slider').swipe({
// 			'swipe': function(event, direction, distance) {
// 			if (direction === 'left') {
//                 event.preventDefault();
//                 event.stopPropagation();
// 				event.stopImmediatePropagation();
// 				$('.takeda-carousel').not(this).trigger('next.owl.carousel');
// 			} else if (direction === 'right') {
//                 event.preventDefault();
//                 event.stopPropagation();
// 				event.stopImmediatePropagation();
// 				$('.takeda-carousel').not(this).trigger('prev.owl.carousel');
// 			}
// 			},
// 			threshold: 10
// 		});


// 		// notifcation slider swipe disable
// 		$('.notification_slider').swipe({
// 			'swipe': function(event, direction, distance) {
// 			if (direction === 'left') {
// 				event.stopImmediatePropagation();
// 				$('.notification-carousel').not(this).trigger('next.owl.carousel');
// 			} else if (direction === 'right') {
// 				event.stopImmediatePropagation();
// 				$('.notification-carousel').not(this).trigger('prev.owl.carousel');
// 			}
// 			},
// 			threshold: 10
// 		});

// 		//ISI body swipe disable
// 		$('#isiMain, .global-side-nav, .homeDisable, #wrapper11').swipe({
// 			'swipe': function(event, direction, distance) {
// 			if (direction === 'left') {
// 				event.stopImmediatePropagation();
// 			} else if (direction === 'right') {
// 				event.stopImmediatePropagation();
// 			}
// 			},
// 			threshold: 10
// 		});
// 	});
// };
"use strict";
//# sourceMappingURL=disable-swipe-action.js.map
