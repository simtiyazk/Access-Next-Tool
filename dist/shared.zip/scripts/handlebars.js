"use strict";

var _config = require("../../access_next_tool_00_00/assets/scripts/config");

var _config2 = _interopRequireDefault(_config);

var _config3 = require("../../access_next_tool_10_00/assets/scripts/config");

var _config4 = _interopRequireDefault(_config3);

var _config5 = require("../../access_next_tool_20_00/assets/scripts/config");

var _config6 = _interopRequireDefault(_config5);

var _config7 = require("../../access_next_tool_30_00/assets/scripts/config");

var _config8 = _interopRequireDefault(_config7);

var _config9 = require("../../access_next_tool_40_00/assets/scripts/config");

var _config10 = _interopRequireDefault(_config9);

var _config11 = require("../../access_next_tool_50_00/assets/scripts/config");

var _config12 = _interopRequireDefault(_config11);

var _config13 = require("../../access_next_tool_60_00/assets/scripts/config");

var _config14 = _interopRequireDefault(_config13);

var _config15 = require("../../access_next_tool_70_00/assets/scripts/config");

var _config16 = _interopRequireDefault(_config15);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

'use strict';

//Use this file for any data, helpers or partial strings you want to use in your slide .hbs files

exports.data = {
   global: {
      prefix: "EHNY"
   },
   slides: {
      access_next_tool_00_00: _config2.default,
      access_next_tool_10_00: _config4.default,
      access_next_tool_20_00: _config6.default,
      access_next_tool_30_00: _config8.default,
      access_next_tool_40_00: _config10.default,
      access_next_tool_50_00: _config12.default,
      access_next_tool_60_00: _config14.default,
      access_next_tool_70_00: _config16.default

   }
};

exports.partials = {
   // footer: '<footer>the end</footer>'
};

exports.helpers = {
   // capitals: function(str) {
   //    return str.toUpperCase();
   // }
};
//# sourceMappingURL=handlebars.js.map
